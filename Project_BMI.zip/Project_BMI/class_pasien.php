<?php
require_once 'class_BMI.php';
require_once 'class_bmipasien.php';
class Pasien {
    public $kode;
    public $nama;
    public $gender;

     public function __construct( $kode, $nama, $gender)
    {
        $this->kode = $kode;
        $this->nama = $nama;
        $this->gender = $gender;
    }

}