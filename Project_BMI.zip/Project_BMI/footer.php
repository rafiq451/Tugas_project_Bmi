 <!-- Main Footer -->
 <footer class="main-footer">
        <strong>Copyright &copy; 2014-2021 <a href="#">SIPAK STT-NF</a>.</strong>
        <div class="float-right d-sm-inline-block" style="padding: 20px">
          <div class="span6">
            <div class="container">
              <div class="row justify-content-end ml-auto" style="width: 15rem">
                <div class="col-2">
                  <a class="social bi bi-facebook text-dark" href="#" target="_blank"></a>
                </div>
                <div class="col-2">
                  <a class="social bi bi-twitter text-dark" href="#" target="_blank"></a>
                </div>
                <div class="col-2">
                  <a class="social bi bi-instagram text-dark" href="#" target="_blank"></a>
                </div>
                <div class="col-2">
                  <a class="social bi bi-youtube text-dark" href="#" target="_blank"></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
    <!-- ./wrapper -->

    <!-- REQUIRED SCRIPTS -->

    <!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE -->
    <script src="dist/js/adminlte.js"></script>

    <!-- OPTIONAL SCRIPTS -->
    <script src="plugins/chart.js/Chart.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard3.js"></script>
  </body>
</html>
